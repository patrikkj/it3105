@dataclass
class MCNode:
    state: tuple
    parent: 'MCNode' = None
    successors: dict = field(default_factory=dict)
    Q: float = 0            # Expected reward
    E: float = 0            # Total reward (evaluation)
    N: int = 0              # Num. visits
    player: int = 0
    is_leaf: bool = True

    #@lru_cache(maxsize=None)      # Meomizes node generation by state
    @staticmethod
    def from_state(state):
        return MCNode(state=state, player=state[0])

    @property
    def u(self):
        """Exploration bonus"""
        return (math.log(self.parent.N) / (1 + self.N))**0.5

    def uct(self, c, is_max=False):
        """Returns the Upper Confidence Bound for Trees (UCT) metric."""
        return self.Q + c * (self.u if is_max else -self.u)

    def __str__(self):
        return "\n".join(f"{k}: {v}" for k, v in self.__dict__.items() if k not in ("successors", "parent")) if self.N > 0 else ""
    
    def __hash__(self):
        return hash(self.state + self.parent.state if self.parent else tuple())





    

    def search_old(self, env):
        """ (1) - Tree Search
        Traversing the tree from the root to a leaf node by using the tree policy.
        """
        node = self.root
        while not node.is_leaf:
            action = self.tree_policy(node)
            env.move(action, node.player)
            node = node.successors[action]

        # Node is now a leaf node; expand if leaf has been visited before
        if node.N > 0 and not env.is_finished():
            node = self.node_expansion(env, node)
            #action = next(env.get_legal_actions(), None)
            action = self.tree_policy(node)
            env.move(action, node.player)
            node = node.successors[action]
        return node