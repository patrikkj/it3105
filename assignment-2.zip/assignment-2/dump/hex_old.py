"""
    Class for representing the Hex game.
    The class includes all game logic
    The class is instantiated with a given size, which is the size of the board.
    Each cell is represented by (is_player_one, is_player_two), i.e. (0,0) is empty cell

    Note that the board is 1-indexed!!!
"""

import math
import pylab as pl
from matplotlib import collections  as mc
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import RegularPolygon, ConnectionPatch, Polygon
from matplotlib.collections import PatchCollection


class Hex:
    def __init__(self, size, frame_rate = 1):
        self.size = size
        self.board = self.create_board()
        self.frame_rate = frame_rate

    def get_initial_state(self):
        pass

    """
        Note that the board is 1-indexed!!!
    """
    def get_cell(self, row, place):
        if not self.is_valid_cell(row,place):
            pass
        matrix_row, matrix_col = self.get_coordinates(row,place)
        return self.board[matrix_row][matrix_col]

    def is_valid_cell(self, row, place):
        valid_row = row>0 and row<self.size*2
        valid_place = place>0 and ( place <= (self.size - abs(self.size-row)) )
        return valid_row and valid_place

    def create_board(self):
        return [[(0,0) for col in range(self.size)] for row in range(self.size)]

    def is_empty(self, row, place):
        cell = self.get_cell(row,place)
        return cell[0] == 0 and cell[1] == 0

    """
        Alters the state by coloring one cell based on the players turn
        Should check that the move is valid first
    """
    def do_move(self, row, place, player):
        new_cell = (0,1) if int(player) else (1,0)
        matrix_row, matrix_col = self.get_coordinates(row, place)
        self.board[matrix_row][matrix_col] = new_cell

    def get_coordinates(self, row, place):
        matrix_row = max(0, row-self.size) + place - 1
        matrix_col = self.size - min(self.size, row) + place -1
        return matrix_row, matrix_col

    def get_cell_representation(self, row,place):
        matrix_row, matrix_col = self.get_coordinates(row,place)
        cell_value = self.board[matrix_row][matrix_col]
        if cell_value == (0,0): # Not used
            return "#EBEBEB"
        elif cell_value == (1,0): # Player one
            return "#99FF99"
        else:
            return "#FF4A4A" # Player two

    def get_state(self):
        pass

    def get_board(self):
        return self.board

    """
        Plots the board 
    """
    def visualize_board(self):
        HEXSIZE = 0.57
        HEXDIM = 6
        ROW_HEIGHT = -0.8660254038
        ROW_BIAS = -0.5
        cells = [c for c in self if self]
        cell_colors = [self.get_cell_representation(c[0], c[1]) for c in cells]

        fig, ax = plt.subplots()

        # 1. Hex coordinates
        x = [col + (self.size - abs(self.size - row)) * ROW_BIAS for row, col in cells]
        y = [row * ROW_HEIGHT for row, col in cells]
        xy = list(zip(x,y,cell_colors))

        # 2. Create surrounding triangles
        x_C = HEXSIZE*1.5
        y_C = HEXSIZE*2
        lower, upper, left, right = np.argmin(y), np.argmax(y), np.argmin(x), np.argmax(x)
        top, btm, l, r = (x[upper], y[upper]+y_C), (x[lower], y[lower]-y_C), (x[left]-x_C, y[left]), (x[right]+x_C, y[right])  # 4 points in plot
        center = (x[upper], (y[upper]+y[lower])/2)
        p1_triangles = [[top,l,center], [r,btm,center]]
        p2_triangles = [[l,btm,center], [r,top,center]]

        _ = [ax.add_patch(Polygon(pts, closed=False, color = "red",zorder =0, alpha = 0.6))for pts in p1_triangles]
        _ = [ax.add_patch(Polygon(pts, closed=False, color = "green",zorder = 0, alpha = 0.6))for pts in p2_triangles]

        # 3. Create hexes
        patches = [RegularPolygon((x, y), HEXDIM, HEXSIZE, facecolor=color, edgecolor="grey") for x, y, color in xy]
        collection = PatchCollection(patches,
                                     edgecolors='red',
                                     lw=2,
                                     match_original=True
                                     )
        ax.patch.set(facecolor='lightgray')
        ax.add_collection(collection)
        ax.autoscale()
        plt.show(block=True)
        plt.pause(self.frame_rate)
        plt.close()

    def __iter__(self):
        self.row = 1
        self.place = 1
        return self

    def __next__(self):
        position = (self.row, self.place)
        last_place_in_row = self.size - abs(self.row - self.size)

        if self.row == self.size * 2: raise StopIteration

        if self.place == last_place_in_row:
            self.row += 1
            self.place = 1
            return position

        self.place += 1
        return position

    def __str__(self):
        board_string = ""
        for row, place in self:
            if place == 1:
                board_string += "\n"
                board_string += " " * abs(self.size - row)*4
            board_string += f'{self.get_cell(row, place)} '

        return board_string


h = Hex(10)
print(h)
h.do_move(1,1,1)
print(h)
h.do_move(2,1,0)
print(h)
h.visualize_board()